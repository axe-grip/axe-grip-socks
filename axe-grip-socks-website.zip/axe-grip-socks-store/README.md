# AXE Grip Socks — online store starter

This is a responsive AXE storefront with:
- 8 colourways and the agreed stock split (100 pairs total)
- Medium, Large and XL size selection
- €12.95 per pair
- Shopping bag and Stripe Checkout integration
- EU shipping address collection

## Important before taking orders
The Stripe checkout is deliberately not active until a parent/guardian has helped set up the payment account and added the secret key. Do not put your Stripe secret key in `public/app.js` or share it with anyone.

## Run locally
1. Install Node.js.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Add the Stripe secret key and your deployed site URL to `.env`.
6. Run `npm start` and open `http://localhost:3000`.

## Publish
Deploy this Node app to a host that supports server-side Node applications (for example Render or Railway). Add `STRIPE_SECRET_KEY` and `SITE_URL` as private environment variables in the host dashboard. Connect a domain if desired.

A parent/guardian should own or supervise the hosting, payment-provider, tax, returns and customer-data setup. Confirm the correct EU shipping countries, delivery charges, privacy notice and returns policy before launch.

## Inventory note
The site displays the agreed allocation:
- Green & Red: M3 / L6 / XL4
- Maroon & White: M3 / L5 / XL4
- Red & White: M3 / L6 / XL4
- Red & Black: M3 / L6 / XL4
- Green & Gold: M3 / L6 / XL4
- Green & White: M3 / L6 / XL4
- Black & White: M3 / L6 / XL4
- Blue & Gold: M2 / L5 / XL3

Total: 23 Medium, 46 Large, 31 XL = 100 pairs.

This starter validates the quantities sent to checkout, but does not yet reserve/decrement stock after a successful payment. Add a database and Stripe webhook before relying on it for live inventory.
