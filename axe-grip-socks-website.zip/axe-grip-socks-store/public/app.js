const products = [
  {name:"Green & Red", stock:{M:3,L:6,XL:4}, sock:"#14743d", accent:"#d83232"},
  {name:"Maroon & White", stock:{M:3,L:5,XL:4}, sock:"#651d36", accent:"#f7f7f2"},
  {name:"Red & White", stock:{M:3,L:6,XL:4}, sock:"#c92d32", accent:"#f7f7f2"},
  {name:"Red & Black", stock:{M:3,L:6,XL:4}, sock:"#c92d32", accent:"#151515"},
  {name:"Green & Gold", stock:{M:3,L:6,XL:4}, sock:"#176b3b", accent:"#d6ad26"},
  {name:"Green & White", stock:{M:3,L:6,XL:4}, sock:"#176b3b", accent:"#f7f7f2"},
  {name:"Black & White", stock:{M:3,L:6,XL:4}, sock:"#171717", accent:"#f7f7f2"},
  {name:"Blue & Gold", stock:{M:2,L:5,XL:3}, sock:"#24528c", accent:"#d6ad26"}
];
const PRICE = 1295;
let cart = [];
let selectedProduct = null;
let selectedSize = null;
const $ = id => document.getElementById(id);
$("year").textContent = new Date().getFullYear();

function renderProducts(){
  $("productGrid").innerHTML = products.map((p,i)=>`
    <article class="product-card" data-index="${i}" tabindex="0" role="button" aria-label="Choose ${p.name} grip socks">
      <div class="product-art" style="--sock:${p.sock};--accent:${p.accent}">
        <span class="product-index">AXE / 0${i+1}</span>
        <div class="sock-shape"><i class="sock-cuff"></i><i class="sock-sole"></i></div>
      </div>
      <div class="product-info"><div><h3>${p.name}</h3><p>Grip socks · M / L / XL</p></div><span class="product-price">€12.95</span></div>
    </article>`).join("");
  document.querySelectorAll(".product-card").forEach(card=>{
    const open=()=>openModal(Number(card.dataset.index));
    card.addEventListener("click",open);
    card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open();}});
  });
}
function openModal(index){
  selectedProduct=products[index]; selectedSize=null;
  $("modalTitle").textContent="CHOOSE YOUR SIZE";
  $("modalColour").textContent=selectedProduct.name;
  document.querySelectorAll(".size-options button").forEach(b=>b.classList.remove("selected"));
  $("stockMessage").textContent="Select a size to see availability.";
  $("addToBag").disabled=true;
  $("modalBackdrop").classList.add("open");
}
document.querySelectorAll(".size-options button").forEach(button=>button.addEventListener("click",()=>{
  selectedSize=button.dataset.size;
  document.querySelectorAll(".size-options button").forEach(b=>b.classList.toggle("selected",b===button));
  const inCart=cart.filter(x=>x.name===selectedProduct.name&&x.size===selectedSize).reduce((n,x)=>n+x.qty,0);
  const available=selectedProduct.stock[selectedSize]-inCart;
  $("stockMessage").textContent=available>0?`${available} available in this size.`:"Sorry, this size is sold out.";
  $("addToBag").disabled=available<=0;
}));
$("addToBag").addEventListener("click",()=>{
  if(!selectedProduct||!selectedSize)return;
  const existing=cart.find(x=>x.name===selectedProduct.name&&x.size===selectedSize);
  if(existing)existing.qty++;else cart.push({name:selectedProduct.name,size:selectedSize,qty:1});
  $("modalBackdrop").classList.remove("open");renderCart();
});
function renderCart(){
  const count=cart.reduce((n,x)=>n+x.qty,0);
  $("cartCount").textContent=count;
  $("subtotal").textContent=`€${(count*PRICE/100).toFixed(2)}`;
  $("checkoutBtn").disabled=count===0;
  $("cartItems").innerHTML=cart.length?cart.map((x,i)=>`
    <div class="cart-line"><div><strong>${x.name}</strong><small>Size ${x.size} · Qty ${x.qty}</small></div>
    <div style="text-align:right"><strong>€${(x.qty*PRICE/100).toFixed(2)}</strong><button class="remove" data-remove="${i}">Remove</button></div></div>`).join(""):'<p class="empty">Your bag is empty.</p>';
  document.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{cart.splice(Number(b.dataset.remove),1);renderCart();}));
}
function toggleCart(open){$("cartDrawer").classList.toggle("open",open);$("cartBackdrop").classList.toggle("open",open);$("cartDrawer").setAttribute("aria-hidden",String(!open));}
$("cartToggle").addEventListener("click",()=>toggleCart(true));
$("closeCart").addEventListener("click",()=>toggleCart(false));
$("cartBackdrop").addEventListener("click",()=>toggleCart(false));
$("closeModal").addEventListener("click",()=>$("modalBackdrop").classList.remove("open"));
$("modalBackdrop").addEventListener("click",e=>{if(e.target===$("modalBackdrop"))$("modalBackdrop").classList.remove("open");});
$("checkoutBtn").addEventListener("click",async()=>{
  const button=$("checkoutBtn");button.disabled=true;button.textContent="CONNECTING TO CHECKOUT…";
  try{
    const response=await fetch("/create-checkout-session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:cart})});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||"Checkout is not configured yet.");
    window.location.href=data.url;
  }catch(error){
    alert(error.message+" Ask your parent/guardian to finish the Stripe setup before accepting payments.");
    button.disabled=false;button.innerHTML='CHECKOUT <b>↗</b>';
  }
});
renderProducts();renderCart();
