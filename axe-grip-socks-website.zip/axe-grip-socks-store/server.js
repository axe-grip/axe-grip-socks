import express from "express";
import Stripe from "stripe";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const inventory = {
  "Green & Red": { M:3, L:6, XL:4 },
  "Maroon & White": { M:3, L:5, XL:4 },
  "Red & White": { M:3, L:6, XL:4 },
  "Red & Black": { M:3, L:6, XL:4 },
  "Green & Gold": { M:3, L:6, XL:4 },
  "Green & White": { M:3, L:6, XL:4 },
  "Black & White": { M:3, L:6, XL:4 },
  "Blue & Gold": { M:2, L:5, XL:3 }
};
const PRICE_CENTS = 1295;

app.post("/create-checkout-session", async (req, res) => {
  if (!stripe) return res.status(503).json({ error: "Secure checkout has not been connected yet." });
  try {
    const items = req.body.items;
    if (!Array.isArray(items) || !items.length) return res.status(400).json({error:"Your bag is empty."});
    const line_items = items.map(item => {
      if (!inventory[item.name] || !["M","L","XL"].includes(item.size) ||
          !Number.isInteger(item.qty) || item.qty < 1 || item.qty > inventory[item.name][item.size]) {
        throw new Error("One of your selected options is unavailable.");
      }
      return {
        quantity: item.qty,
        price_data: {
          currency: "eur",
          unit_amount: PRICE_CENTS,
          product_data: { name: `AXE Grip Socks — ${item.name}`, description: `Size ${item.size}` }
        }
      };
    });
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      shipping_address_collection: { allowed_countries: ["AT","BE","BG","HR","CY","CZ","DK","EE","FI","FR","DE","GR","HU","IE","IT","LV","LT","LU","MT","NL","PL","PT","RO","SK","SI","ES","SE"] },
      success_url: `${process.env.SITE_URL}/?checkout=success`,
      cancel_url: `${process.env.SITE_URL}/?checkout=cancelled`
    });
    res.json({url:session.url});
  } catch (error) {
    res.status(400).json({error:error.message || "Unable to start checkout."});
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AXE store running on port ${port}`));
